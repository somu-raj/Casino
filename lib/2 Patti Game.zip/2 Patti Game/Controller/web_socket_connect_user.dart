import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../../Helper_Constants/Images_path.dart';
import '../../Helper_Constants/colors.dart';
import '../../Widgets/coins_widget.dart';
import '../../audio_controller.dart';
import '../poker.dart';
import 'controller.dart';

class WebSocketConnect extends StatefulWidget {
  const WebSocketConnect({super.key,required this.audioController});
  final AudioController audioController;

  @override
  State<WebSocketConnect> createState() => _WebSocketConnectState();
}

class _WebSocketConnectState extends State<WebSocketConnect> {
  PokerController pokerController = Get.put(PokerController());

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [SystemUiOverlay.bottom],
    );
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            colors.secondary.withOpacity(0.9),
            colors.primary,
            colors.secondary.withOpacity(0.9),
          ]),
          image: const DecorationImage(
            image: AssetImage(ImagesPath.backGroundImage),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Obx(() {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CoinWidget(
                          foreGroundColor: Colors.red.shade900,
                          text: "100",
                          onTap: () {
                            pokerController.onCoinTap(100);
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>  PokerTable(pokerController: pokerController,)));
                          },
                          selected: pokerController.selectedCoin.value == 100),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CoinWidget(
                          foreGroundColor: Colors.yellow.shade900,
                          text: "200",
                          onTap: () {
                            pokerController.onCoinTap(200);
                          },
                          selected: pokerController.selectedCoin.value == 200),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CoinWidget(
                          foreGroundColor: Colors.blueGrey.shade700,
                          text: "500",
                          onTap: () {
                            pokerController.onCoinTap(500);
                          },
                          selected: pokerController.selectedCoin.value == 500),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CoinWidget(
                          foreGroundColor: Colors.pink.shade900,
                          text: "1000",
                          onTap: () {
                            pokerController.onCoinTap(1000);
                          },
                          selected: pokerController.selectedCoin.value == 1000),
                    ),
                  ],
                ),
              );
            })
          ],
        ),
      ),
    );
  }
}
