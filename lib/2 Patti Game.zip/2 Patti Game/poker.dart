import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:roullet_app/Helper_Constants/other_constants.dart';
import 'package:roullet_app/Ludo/util/colors.dart';
import 'package:socket_io_client/socket_io_client.dart'as IO;

import '../Helper_Constants/Images_path.dart';
import '../Helper_Constants/colors.dart';
import '../Widgets/coins_widget.dart';
import '../utils.dart';
import 'Controller/controller.dart';
import 'card_ui.dart';

class PokerTable extends StatefulWidget {
  const PokerTable({super.key, required this.pokerController});
  final PokerController pokerController;

  @override
  _PokerTableState createState() => _PokerTableState();
}

class _PokerTableState extends State<PokerTable> {
  late IO.Socket socket;
  bool isPlayer1CardsVisible = false;

  @override
  void initState() {
    super.initState();
    for (int i = 1; i < 14; i++) {
      String? card;
      switch (i) {
        case 1:
          card = 'ace';
          break;
        case 11:
          card = 'jack';
          break;
        case 12:
          card = 'queen';
          break;
        case 13:
          card = 'king';
          break;
        default:
          card = "$i";
          break;
      }
      for (int j = 0; j < 4; j++) {
        String? suit;
        switch (j) {
          case 0:
            suit = 'clubs';
            break;
          case 1:
            suit = 'diamonds';
            break;
          case 2:
            suit = 'hearts';
            break;
          default:
            suit = "spades";
            break;
        }
        widget.pokerController.cardNumber.add('${card}_of_$suit');
      }
    }
    debugPrint("card number --> ${widget.pokerController.cardNumber}");

    // Shuffle and deal the cards
    widget.pokerController.dealCards();
    // connectToServer();
  }

  void connectToServer() {
    socket = IO.io('http://localhost:3000', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
    });

    socket.connect();

    socket.on('connect', (_) {
      print('connected to server');
      socket.emit('join', 'poker-room'); // joining the poker room
    });

    socket.on('disconnect', (_) {
      print('disconnected from server');
    });

    // handle custom events here
    socket.on('player_joined', (data) {
      print('Player joined: $data');
    });

    socket.on('card_distribution', (data) {
      print('Cards distributed: $data');
    });

    socket.on('bet', (data) {
      print('Bet placed: $data');
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [SystemUiOverlay.bottom],
    );
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                colors.secondary.withOpacity(0.9),
                colors.primary,
                colors.secondary.withOpacity(0.9),
              ]),
              image: const DecorationImage(
                image: AssetImage(ImagesPath.backGroundImage),
                fit: BoxFit.fill,
              ),
            ),
          ),
          Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 300,
                height: 140,
                decoration: BoxDecoration(
                  color: colors.primary,
                  border: Border.all(color: const Color(0XFF623412), width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0XFF623412),
                      blurRadius: 3.0,
                      spreadRadius: 1.0,
                    )
                  ],
                  borderRadius: BorderRadius.circular(75),
                ),
                child: const Center(
                  child: Text(
                    'Poker Table',
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
              ),
              Positioned(
                top: -110,
                child: PlayerWidget(
                  playerImage: widget.pokerController.playersImage[0],
                  playerName: widget.pokerController.players[0],
                  cards: widget.pokerController.playerCards[0],
                  isCurrentPlayer: widget.pokerController.currentPlayerIndex == 0,
                  leftRightTop: (false, false, true),
                  amount: widget.pokerController.playerAmounts[0],
                  showCards: isPlayer1CardsVisible,
                ),
              ),
              Positioned(
                left: -80,
                top: 40,
                child: PlayerWidget(
                  playerName: widget.pokerController.players[1],
                  playerImage: widget.pokerController.playersImage[1],
                  cards: widget.pokerController.playerCards[1],
                  isCurrentPlayer: widget.pokerController.currentPlayerIndex == 1,
                  leftRightTop: (true, false, false),
                  amount: widget.pokerController.playerAmounts[1],
                  showCards: false,
                ),
              ),
              Positioned(
                right: -80,
                top: 40,
                child: PlayerWidget(
                  playerName: widget.pokerController.players[2],
                  playerImage: widget.pokerController.playersImage[2],
                  cards: widget.pokerController.playerCards[2],
                  isCurrentPlayer: widget.pokerController.currentPlayerIndex == 2,
                  leftRightTop: (false, true, false),
                  amount: widget.pokerController.playerAmounts[2],
                  showCards: false,
                ),
              ),
              Positioned(
                bottom: -110,
                child: Obx(() {
                  return PlayerWidget(
                    playerName: widget.pokerController.isProfileUpdated.value
                        ? (widget.pokerController.getProfileModel?.data.first.username ?? "")
                        : widget.pokerController.players[3],
                    playerImage: widget.pokerController.playersImage[3],
                    cards: widget.pokerController.playerCards[3],
                    isCurrentPlayer: widget.pokerController.currentPlayerIndex == 3,
                    leftRightTop: (false, false, false),
                    amount: widget.pokerController.playerAmounts[3],
                    showCards: false,
                  );
                }),
              ),
            ],
          ),
          Positioned(
              bottom: 10,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: (){
                          Utils.mySnackBar(title: "is't my side pack");
                        },
                        child: Container(
                            height: 40,
                            width: 60,
                            decoration: BoxDecoration(
                                color: colors.red.withOpacity(0.4),
                                border: Border.all(color: colors.borderColorLight,width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            child: const  Center(child:  Text("Pack",style: TextStyle(color: colors.whiteTemp),))
                        ),
                      ),
                      const SizedBox(width: 20,),
                      InkWell(
                        onTap: () {
                          setState(() {
                            isPlayer1CardsVisible = !isPlayer1CardsVisible;
                          });
                        },
                        child: Container(
                            height: 40,
                            width: 80,
                            decoration: BoxDecoration(
                                color: colors.primary.withOpacity(0.4),
                                border: Border.all(color: colors.borderColorLight,width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            child: const  Center(child:  Text("Show",style: TextStyle(color: colors.whiteTemp),))
                        ),
                      ),
                    ],
                  ) ,
                  const SizedBox(width: 200),
                  Row(
                    children: [
                      Container(
                        width: 100,
                        height: 40,
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),border: Border.all(color: colors.borderColorLight,width: 2)),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Obx(()=> Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              widget.pokerController.amount == 5 ? const SizedBox.shrink():  InkWell(
                                  onTap: (){
                                    widget.pokerController.decrementAmount();
                                  },
                                  child: const Icon(Icons.remove,color: colors.whiteTemp,)),
                              Text(
                                '${widget.pokerController.amount}',
                                style: const TextStyle(fontSize: 20.0,color: colors.whiteTemp),
                              ),
                              InkWell(
                                  onTap: (){
                                    widget.pokerController.incrementAmount();
                                  },
                                  child: const Icon(Icons.add,color: colors.whiteTemp,)),
                            ],
                          ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 20,),
                      InkWell(
                        onTap: (){
                          Utils.mySnackBar(title: "This is a my chal");
                        },
                        child: Container(
                            height: 40,
                            width: 60,
                            decoration: BoxDecoration(
                                color: colors.primary.withOpacity(0.4),
                                border: Border.all(color: colors.borderColorLight,width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            child: const  Center(child:  Text("Chal",style: TextStyle(color: colors.whiteTemp),))
                        ),
                      ),
                    ],
                  )
                ],
              )
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    socket.dispose();
    super.dispose();
  }
}
